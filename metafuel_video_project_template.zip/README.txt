MetaFuel Ultra — Video Project Template
======================================

Folders:
- footage/   -> ضع هنا تسجيلات الشاشة والصوت وأي وسائط
- timelines/ -> يحتوي ملفات الجدول الزمني (CSV + XML + EDL)
- exports/   -> ضع هنا ملفات الإخراج النهائية بعد التصدير

Included Timelines:
- metafuel_video_timeline.csv  (للمراجعة السريعة/Google Sheets/Excel)
- metafuel_video_timeline.xml  (Markers & Sequence لPremiere/Resolve)
- metafuel_video_timeline.edl  (Timeline Events للبرامج التي تفضّل EDL)

How to import (Premiere Pro):
1) File -> Import... -> اختر timelines/metafuel_video_timeline.xml
2) سيظهر Sequence باسم "MetaFuel Tutorial Timeline" مع Markers.
3) اسحب مقاطعك من مجلد footage/ إلى التايملاين.
4) استخدم الملاحظات (Markers) كأدلة للقطع والكتابة.
5) للتصدير: File -> Export -> Media... واحفظ إلى exports/

How to import (DaVinci Resolve):
1) في Media Pool: Right click -> Import Timeline -> Import AAF, EDL, XML
2) اختر metafuel_video_timeline.xml
3) سيتم إنشاء Timeline مع Markers. اسحب وسائطك من footage/.
4) للتصدير: Deliver -> اختر الإعداد المناسب واحفظ إلى exports/

Notes:
- أخفِ أي أسرار (API Keys) أثناء التسجيل أو قم بطمسها (Blur).
- التوقيتات مبنية على 30fps، غيّرها إن كان مشروعك مختلف.
- يمكنك تعديل CSV وإعادة توليد XML/EDL لاحقًا إذا رغبت.

بالتوفيق! 🚀
